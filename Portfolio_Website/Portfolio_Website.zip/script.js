var menubtn = document.getElementById('menubtn');
	var nav = document.querySelector('nav');

	menubtn.onclick = function(){
		nav.classList.toggle('opened');
		if(nav.classList.contains('opened')){
			menubtn.innerText = 'close';
		}
		else{
			
			menubtn.innerText = 'open';
		}
		
	}


// menuToggle

var arrTop = document.getElementById('totop');

//sticky header   +
var STICKY = 600;
var header = document.querySelector('header');

// progressbars
var progressbars = document.querySelectorAll('.progress');
var progressAnimated = false;
var skillsSection = document.querySelector('.skills');
var skillsTop = skillsSection.offsetTop - 200;

//counters
var counters = document.querySelectorAll('.cont');
var countersAnimated = false;
var countersSection = document.querySelector('.stats');
var countersTop = countersSection.offsetTop - 300;

document.addEventListener('scroll', function(){
	var scrollTop = document.documentElement.scrollTop || document.scrollingElement.scrollTop;
	if(scrollTop > STICKY){

		header.classList.add('sticky');
		// show arrow after 1st section
		arrTop.style.display = 'block';

		if(scrollTop > skillsTop && !progressAnimated){
			progressAnimated = !progressAnimated;
			for(var i = 0; i < progressbars.length; i++){
				animateProgressbar(progressbars[i]);
			}
		}
		if(scrollTop > countersTop && !countersAnimated){
			console.log('scroll');
			countersAnimated = !countersAnimated;
			for (var i = 0; i < counters.length; i++){
				animateCounter(counters[i]);
			}
		}
	}
	else{
		header.classList.remove('sticky');
		arrTop.style.display = 'none';
	}
});

function animateProgressbar(progressbar){
	var value = progressbar.getAttribute('data-value');
	var max = 100;
	var delta = value/max;
	var current = 0;

	var timerId = setInterval(function(){
		if(current < value){
			current += delta;
			progressbar.style.width = current + "%";
		}
		else{
			clearInterval(timerId);
		}
	}, 7);
}

// load more

var loadBtn = document.querySelector('.more-button');
var pfItems = document.querySelectorAll('.portfolio-item');
var current = 6;
var step = 6;
loadBtn.onclick = loadMore;

function loadMore(){
	if (current + step <= pfItems.length){
		for(var i = current -1; i < current+step; i++){
			pfItems[i].style.display = 'block';
		}
		current += step;
		if(current == pfItems.length){
			loadBtn.style.display = 'none';
		}
	}
}

// counters
function animateCounter(counter){
	var value = counter.getAttribute('data-count');
	var delta = 1500/value;
	var currentCount = 0;

	var timer = setInterval(function(){
		if(currentCount <= value){
			currentCount++;
			counter.innerText = currentCount;
		}
		else{
			clearInterval(timer);
		}
	}, delta);
}



// loader